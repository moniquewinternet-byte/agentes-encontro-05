# Identidade visual da aluna

O painel sai com a SUA cara (as 3 cores e a fonte que você montou no Encontro 02).
Troque os valores abaixo pelos seus. Enquanto não trocar, o painel usa um visual neutro.

- Cor principal: #0d9488
- Cor de destaque: #d97706
- Fonte: Inter

(As cores de status, verde pra entrou e vermelho pra saiu, não mudam: são sinal, não marca.)
Os valores acima são EXEMPLO pra aula. Troque pelas suas cores do Encontro 02.
