# O que o Organizador Financeiro aprendeu sobre estes gastos

Atualizado a cada uso. Guarda só REGRAS de categoria, nunca os valores do extrato.

## Como funciona
Cada lançamento é categorizado pela descrição. O que não casar com nenhuma regra entra como
"A classificar", e você pergunta pra ela. Quando ela responde, a regra nova entra aqui (com a
trava do fim do arquivo).

## Regras que já vêm prontas (palavra na descrição, categoria)
- Moradia: aluguel, condominio, imobiliaria
- Contas da casa: energia, luz, agua, saneamento, internet, telefone, gas
- Mercado: supermercado, mercado, hortifruti, atacadao, atacado
- Alimentação (delivery): ifood, rappi, uber eats, delivery
- Restaurante e bar: restaurante, lanchonete, padaria, bar, cafe, pizzaria
- Transporte: uber, 99, taxi, posto, combustivel, gasolina, estacionamento, metro, onibus, bilhete
- Saúde e bem-estar: farmacia, drogaria, clinica, dentista, medico, exame, laboratorio, academia
- Assinaturas: netflix, spotify, deezer, amazon prime, disney, hbo, max, youtube premium, clube, revista, assinatura
- Educação: curso, faculdade, escola, livro, livraria, workshop
- Lazer e viagem: cinema, show, ingresso, viagem, passagem, hotel, airbnb, cvc
- Compras e vestuário: loja, shopping, roupas, calcados, magazine, fashion
- Pet: pet shop, petshop, racao, veterinario, vet
- Tarifas e juros: tarifa, anuidade, iof, juros, cheque especial
- Dívidas: emprestimo, parcela, financiamento, fatura, cartao de credito
- Renda (entrada): salario, credito, pix recebido, rendimento, deposito, transferencia recebida

## Sempre "A classificar" (pergunte, não chute)
Descrições que o banco não explica, por isso NÃO têm categoria automática:
- "PIX ENVIADO <nome>" e "PIX RECEBIDO <nome>" (pode ser qualquer coisa)
- "COMPRA CARTAO <número>" sem o nome da loja
- "TED", "DOC", "TRANSFERENCIA" sem destino claro
Mostre esses pra ela e pergunte a categoria. Só então vira regra.

## Aprendido na prática
(vazio por enquanto. O que ela te ensinar entra aqui.)

## A trava (pra nunca categorizar errado por chute)
- Uma correção de um caso só entra como OBSERVAÇÃO, não como regra fixa.
- Só vira REGRA FIXA depois que ela confirmar, ou depois de o mesmo padrão repetir.
- Nunca decida "sempre" por um caso só. Na dúvida, pergunte.
- Guarde só a regra (palavra, categoria), nunca o valor nem o dado sensível.
