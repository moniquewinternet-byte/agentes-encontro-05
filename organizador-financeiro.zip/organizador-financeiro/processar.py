# -*- coding: utf-8 -*-
"""Ferramenta do Organizador Financeiro.
Le o extrato mais novo da pasta entrada/ (PDF, CSV ou OFX), categoriza pelas regras
do memoria-categorias.md, monta a planilha com soma POR FORMULA (SUMIFS) e gera o
painel visual (na identidade da aluna), um resumo, e a camada de negocio quando houver.
Nao altera, nao paga, nao move dinheiro. Nunca inventa numero.

Uso:  python processar.py
"""
import sys, re, csv, pathlib, datetime, statistics
from collections import defaultdict, Counter

BASE = pathlib.Path(__file__).resolve().parent
ENTRADA = BASE / "entrada"
PAINEL = BASE / "painel"
MODELO = BASE / "modelo-painel.html"
MEMORIA = BASE / "memoria-categorias.md"
CONFIG = BASE / "rotina-config.md"
IDENT = BASE / "identidade.md"
HOJE = datetime.date.today().isoformat()
AMBIGUO = ["pix enviado", "compra cartao", "ted ", "doc ", "saque"]
DISCRICIONARIO = ["deliver", "restaurante", "assinatura", "lazer", "compras", "vestuario"]


# ---------------- formato de dinheiro ----------------
def parse_br(s):
    return float(s.replace(".", "").replace(",", "."))


def br(v):
    return f"{abs(v):,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def brs(v):
    return ("-" if v < 0 else "") + br(v)


def _num(s):
    """Le um numero de dinheiro em texto livre (R$ 4.000,00 / 4000 / 30%)."""
    s = re.sub(r"[^\d,\.]", "", s)
    if not s:
        return None
    if "," in s:
        return parse_br(s)
    if s.count(".") == 1 and len(s.split(".")[1]) == 2:
        return float(s)
    return float(s.replace(".", ""))


def _sem_acento(s):
    """Tira acento e deixa minusculo, pra comparar sem erro de caixa."""
    import unicodedata
    return "".join(c for c in unicodedata.normalize("NFD", s)
                   if unicodedata.category(c) != "Mn").lower()


# ---------------- configuracao e identidade ----------------
def carrega_config():
    cfg = {"meta": None, "negocio": False, "margem": 0.30}
    if not CONFIG.exists():
        return cfg
    for linha in CONFIG.read_text(encoding="utf-8").splitlines():
        l = _sem_acento(linha)
        if not l.strip().startswith("-"):
            continue
        if "meta" in l:
            cfg["meta"] = _num(linha.split(":", 1)[-1]) if ":" in linha else None
        elif "negocio" in l:
            cfg["negocio"] = "sim" in l.split("?")[-1] if "?" in l else "sim" in l
        elif "margem" in l:
            m = _num(linha.split(":", 1)[-1]) if ":" in linha else None
            if m:
                cfg["margem"] = m / 100 if m > 1 else m
    return cfg


def carrega_identidade():
    if not IDENT.exists():
        return None
    ident = {}
    for linha in IDENT.read_text(encoding="utf-8").splitlines():
        l = _sem_acento(linha)
        if not l.strip().startswith("-"):
            continue
        hexc = re.search(r"#[0-9a-fA-F]{3,6}", linha)
        if "principal" in l and hexc:
            ident["principal"] = hexc.group(0)
        elif "destaque" in l and hexc:
            ident["destaque"] = hexc.group(0)
        elif "fonte" in l and ":" in linha:
            ident["fonte"] = linha.split(":", 1)[1].strip()
    return ident or None


# ---------------- regras de categoria (vem do memoria-categorias.md) ----------------
def carrega_regras():
    regras = []
    if not MEMORIA.exists():
        return regras
    txt = MEMORIA.read_text(encoding="utf-8")
    for sec in re.split(r"^##\s+", txt, flags=re.M):
        titulo = _sem_acento(sec.splitlines()[0]) if sec.strip() else ""
        if "regras que ja vem" in titulo or "aprendido na pratica" in titulo:
            for linha in sec.splitlines():
                m = re.match(r"^-\s+(.+?):\s+(.+)$", linha.strip())
                if m:
                    cat = m.group(1).strip()
                    if _sem_acento(cat).startswith("renda"):
                        continue
                    chaves = [k.strip().lower() for k in m.group(2).split(",") if k.strip()]
                    regras.append((cat, chaves))
    return regras


def categoriza(desc, valor, regras):
    """Entrada vira Renda. Senao: tenta as regras de categoria PRIMEIRO; so cai em
    'A classificar' quando nenhuma regra casa E o texto e ambiguo (ex.: PIX ENVIADO)."""
    d = desc.lower()
    if valor >= 0:
        return "Renda", False
    for cat, chaves in regras:
        if any(k in d for k in chaves):
            return cat, False
    for pre in AMBIGUO:
        if pre in d:
            return "A classificar", True
    return "Outros", False


# ---------------- leitura dos 3 formatos ----------------
def le_csv(p):
    out = []
    rows = list(csv.DictReader(open(p, encoding="utf-8-sig")))
    if not rows:
        return out
    cols = {c.lower(): c for c in rows[0].keys()}
    cdata = next((cols[c] for c in cols if "data" in c), None)
    cdesc = next((cols[c] for c in cols if "desc" in c or "histor" in c), None)
    cval = next((cols[c] for c in cols if "valor" in c or "montante" in c), None)
    ctipo = next((cols[c] for c in cols if "tipo" in c or "entrada" in c), None)
    if not (cdata and cdesc and cval):
        return out
    for r in rows:
        raw = (r[cval] or "").strip()
        if not raw:
            continue
        v = parse_br(raw) if ("," in raw) else float(raw)
        if ctipo and r.get(ctipo, "").strip().lower().startswith("saida") and v > 0:
            v = -v
        out.append({"data": r[cdata].strip(), "desc": r[cdesc].strip(), "valor": v})
    return out


def le_ofx(p):
    from ofxparse import OfxParser
    with open(p, "rb") as f:
        ofx = OfxParser.parse(f)
    return [{"data": t.date.strftime("%d/%m/%Y"),
             "desc": (t.memo or t.payee or "").strip(),
             "valor": float(t.amount)}
            for t in ofx.account.statement.transactions]


def le_pdf(p):
    """Leitura tolerante: tenta o formato data+historico+valor+saldo; se achar pouco,
    tenta data+historico+valor no fim da linha. PDF de banco varia muito, entao se vier
    vazio, o certo e exportar OFX/CSV ou deixar a IA ler no modo normal."""
    import pdfplumber
    linhas = []
    with pdfplumber.open(p) as pdf:
        for pg in pdf.pages:
            linhas += (pg.extract_text() or "").splitlines()
    data = r"(\d{2}/\d{2}/\d{2,4})"
    val = r"([+-]?)\s*(\d{1,3}(?:\.\d{3})*,\d{2})"
    p1 = re.compile(rf"^{data}\s+(.*?)\s+{val}\s+-?\s*\d{{1,3}}(?:\.\d{{3}})*,\d{{2}}\s*$")
    p2 = re.compile(rf"^{data}\s+(.*?)\s+{val}\s*(D|C)?\s*$")
    # grupos: 1=data, 2=historico, 3=sinal, 4=numero, (p2) 5=D/C
    out = []
    for raw in linhas:
        l = raw.strip()
        m = p1.match(l)
        if not m:
            m = p2.match(l)
            if not m:
                continue
        sinal = -1 if m.group(3) == "-" else 1
        if m.re is p2 and m.lastindex >= 5 and m.group(5) == "D":
            sinal = -1
        out.append({"data": m.group(1), "desc": m.group(2).strip(),
                    "valor": sinal * parse_br(m.group(4))})
    return out


def le_extrato(p):
    ext = p.suffix.lower()
    if ext == ".csv":
        return le_csv(p)
    if ext == ".ofx":
        return le_ofx(p)
    if ext == ".pdf":
        return le_pdf(p)
    raise ValueError("formato nao suportado: " + ext)


# ---------------- planilha com soma POR FORMULA ----------------
def monta_planilha(lanc, destino):
    import openpyxl
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Lancamentos"
    ws.append(["Data", "Descricao", "Valor", "Tipo", "Categoria"])
    for x in lanc:
        ws.append([x["data"], x["desc"], x["valor"],
                   "Entrada" if x["valor"] >= 0 else "Saida", x["cat"]])
    n = len(lanc) + 1
    C, E = f"$C$2:$C${n}", f"$E$2:$E${n}"
    cats = []
    for x in lanc:
        if x["valor"] < 0 and x["cat"] not in cats:
            cats.append(x["cat"])
    rs = wb.create_sheet("Resumo")
    rs.append(["Categoria", "Total gasto (R$)"])
    for i, c in enumerate(cats, start=2):
        rs.cell(i, 1, c)
        rs.cell(i, 2).value = f'=-SUMIFS(Lancamentos!{C},Lancamentos!{E},A{i},Lancamentos!{C},"<0")'
    b = len(cats) + 3
    rs.cell(b, 1, "Entradas"); rs.cell(b, 2).value = f'=SUMIFS(Lancamentos!{C},Lancamentos!{C},">0")'
    rs.cell(b + 1, 1, "Saidas"); rs.cell(b + 1, 2).value = f'=-SUMIFS(Lancamentos!{C},Lancamentos!{C},"<0")'
    rs.cell(b + 2, 1, "Sobrou"); rs.cell(b + 2, 2).value = f"=SUM(Lancamentos!{C})"
    wb.save(destino)


# ---------------- leitura humana (gerada do dado) ----------------
def gera_destaques(lanc, por_cat, saidas, sobrou, meta):
    dest = []
    top3 = list(por_cat.items())[:3]
    dest.append(("TOP", "Seus 3 maiores gastos: " +
                 ", ".join(f"{c} (R$ {br(v)})" for c, v in top3) + "."))
    deliv = defaultdict(float)
    for x in lanc:
        if "deliver" in _sem_acento(x["cat"]):
            deliv[x["data"][3:]] += -x["valor"]
    if len(deliv) >= 2:
        ks = sorted(deliv, key=lambda k: (k[-4:], k[:2]))
        if deliv[ks[-1]] > deliv[ks[0]]:
            dest.append(("SOBE", f"Seu delivery subiu de R$ {br(deliv[ks[0]])} para R$ {br(deliv[ks[-1]])} no periodo. Vale um olhar."))
    descs = " ".join(x["desc"].lower() for x in lanc)
    if "spotify" in descs and "deezer" in descs:
        dest.append(("REPETE", "Voce paga Spotify e Deezer ao mesmo tempo, dois servicos de musica. Da pra ficar com um so."))
    meses_assin = defaultdict(set)
    total_assin = 0.0
    for x in lanc:
        if x["valor"] < 0 and _sem_acento(x["cat"]).startswith("assinatura"):
            nome = re.sub(r"(?i)^assinatura\s*-\s*", "", x["desc"]).strip()
            meses_assin[nome].add(x["data"][3:])
            total_assin += -x["valor"]
    recorrentes = sorted(n for n, ms in meses_assin.items() if len(ms) >= 2)
    if recorrentes:
        dest.append(("ESQUEC", "Assinaturas que repetem todo mes: " + ", ".join(recorrentes) +
                     f". Juntas somaram R$ {br(total_assin)} no periodo. Vale revisar se usa todas."))
    desp = [x for x in lanc if x["valor"] < 0]
    if desp:
        cont = Counter(x["desc"] for x in desp)
        med = statistics.median([-x["valor"] for x in desp])
        unicos = [x for x in desp if cont[x["desc"]] == 1]
        if unicos:
            out = min(unicos, key=lambda x: x["valor"])
            if -out["valor"] >= 2 * med:
                dest.append(("PICO", f"Gasto fora do padrao: {out['desc']} de R$ {br(out['valor'])} em {out['data']}, bem acima do seu normal."))
        for (dt, ds, vl), c in Counter((x["data"], x["desc"], x["valor"]) for x in desp).items():
            if c > 1:
                dest.append(("DOBRO", f"Cobranca repetida: {ds} de R$ {br(vl)} apareceu {c}x no mesmo dia ({dt}). Vale conferir se nao e erro."))
    tarifa = sum(-x["valor"] for x in lanc if _sem_acento(x["cat"]).startswith("tarifa"))
    if tarifa:
        dest.append(("TARIFA", f"Tarifas e juros somaram R$ {br(tarifa)} no periodo. Muitas vezes da pra pedir isencao no banco."))
    # meta: quanto sobra por mes x a meta, e o que cortar
    if meta and meta > 0:
        nm = max(1, len({x["data"][3:] for x in lanc}))
        sobra_mes = sobrou / nm
        if sobra_mes >= meta:
            dest.append(("META", f"Voce guarda em media R$ {br(sobra_mes)} por mes, acima da sua meta de R$ {br(meta)}. Mandou bem."))
        else:
            falta = meta - sobra_mes
            discr = sorted(((c, v / nm) for c, v in por_cat.items()
                            if any(t in _sem_acento(c) for t in DISCRICIONARIO)),
                           key=lambda kv: -kv[1])
            alvo = ", ".join(f"{c} (R$ {br(v)}/mes)" for c, v in discr[:3]) if discr else "os gastos que da pra cortar"
            dest.append(("META", f"Faltam R$ {br(falta)} por mes pra sua meta de R$ {br(meta)}. Da pra tirar de: {alvo}."))
    ac_n = sum(1 for x in lanc if x["ac"])
    ac_v = sum(-x["valor"] for x in lanc if x["ac"])
    if ac_n:
        dest.append(("PERGUNTA", f"Tem {ac_n} lancamentos que nao deu pra classificar sozinho (R$ {br(ac_v)}, tipo PIX ENVIADO e COMPRA CARTAO). Diga o que sao e eu aprendo."))
    return dest


# ---------------- camada de negocio (markup) ----------------
def processa_negocio(margem, destino_md):
    vfile = BASE / "vendas-negocio-exemplo.csv"
    dfile = BASE / "despesas-negocio-exemplo.csv"
    if not (vfile.exists() and dfile.exists()):
        return None
    vendas = list(csv.DictReader(open(vfile, encoding="utf-8-sig")))
    despesas = list(csv.DictReader(open(dfile, encoding="utf-8-sig")))
    if not vendas:
        return None

    def col(row, *alvos):
        for k in row:
            kl = _sem_acento(k)
            if any(a in kl for a in alvos):
                return row[k]
        return ""

    def num(x):
        x = str(x).strip()
        if not x:
            return 0.0
        try:
            return float(x)          # CSV comum usa ponto decimal (39.9)
        except ValueError:
            try:
                return parse_br(x)   # fallback pra formato BR (39,90 / 1.316,70)
            except ValueError:
                return 0.0

    fat = cust = qtd_total = 0.0
    prod = {}
    for r in vendas:
        q = num(col(r, "quant"))
        pv = num(col(r, "venda", "preco"))
        cu = num(col(r, "custo"))
        nome = col(r, "produto", "item") or "produto"
        fat += q * pv
        cust += q * cu
        qtd_total += q
        if nome not in prod:
            prod[nome] = {"q": 0, "pv": pv, "cu": cu}
        prod[nome]["q"] += q
    desp_total = sum(num(col(r, "valor", "montante")) for r in despesas)
    lucro = fat - cust - desp_total
    rateio = desp_total / qtd_total if qtd_total else 0

    linhas = [f"# Camada de negocio, {datetime.date.today().strftime('%d/%m/%Y')}", "",
              "## Fechamento do mes",
              f"- Faturamento: R$ {br(fat)}",
              f"- Custo dos produtos: R$ {br(cust)}",
              f"- Despesas fixas: R$ {br(desp_total)}",
              f"- Sobrou (lucro): R$ {brs(lucro)}", "",
              f"## Preco por markup (margem desejada de {br(margem*100)}%)",
              "Preco sugerido = custo do produto + rateio das despesas por unidade + a sua margem.",
              f"Rateio das despesas por unidade vendida: R$ {br(rateio)}.", "",
              "| Produto | Custo | Preco atual | Preco sugerido | Situacao |",
              "|---|---|---|---|---|"]
    for nome, d in prod.items():
        base_unit = d["cu"] + rateio
        sugerido = base_unit * (1 + margem)
        situ = "ok" if d["pv"] >= sugerido else "abaixo do sugerido"
        linhas.append(f"| {nome} | R$ {br(d['cu'])} | R$ {br(d['pv'])} | R$ {br(sugerido)} | {situ} |")
    linhas += ["", "Nada foi alterado. Numeros calculados a partir das suas vendas e despesas."]
    destino_md.write_text("\n".join(linhas), encoding="utf-8")
    return f"Negocio: faturou R$ {br(fat)}, sobrou R$ {brs(lucro)}. Tabela de preco por markup em {destino_md.name}."


# ---------------- painel ----------------
ICONES = {"TOP": "\U0001F4CA", "SOBE": "\U0001F4C8", "REPETE": "\U0001F501",
          "ESQUEC": "\U0001F4A4", "PICO": "⚠️", "DOBRO": "❗",
          "TARIFA": "\U0001F3E6", "META": "\U0001F3AF", "PERGUNTA": "❓"}


def monta_painel(entradas, saidas, sobrou, por_cat, dest, periodo, titular, destino, ident):
    html = MODELO.read_text(encoding="utf-8")
    if ident and ident.get("principal"):
        html = re.sub(r"--cor-principal:#[0-9a-fA-F]{3,6};",
                      f"--cor-principal:{ident['principal']};", html, count=1)
    if ident and ident.get("destaque"):
        html = re.sub(r"--cor-destaque:#[0-9a-fA-F]{3,6};",
                      f"--cor-destaque:{ident['destaque']};", html, count=1)
    if ident and ident.get("fonte"):
        html = re.sub(r"--fonte:[^;]+;",
                      f"--fonte:'{ident['fonte']}',system-ui,-apple-system,Arial,sans-serif;",
                      html, count=1)
    bars = []
    for i, (c, v) in enumerate(por_cat.items()):
        pct = v / saidas * 100 if saidas else 0
        classe = "fill maior" if i == 0 else "fill"
        bars.append(f'<div class="barra"><div class="topo"><span class="cat">{c}</span>'
                    f'<span class="num">R$ {br(v)} &middot; {pct:.0f}%</span></div>'
                    f'<div class="trilho"><div class="{classe}" style="width:{pct:.1f}%"></div></div></div>')
    dests = "".join(f'<li><span class="ic">{ICONES.get(k, "&bull;")}</span><span>{t}</span></li>' for k, t in dest)

    def troca(txt, ini, fim, novo):
        a = txt.index(ini) + len(ini); b = txt.index(fim)
        return txt[:a] + novo + txt[b:]

    html = troca(html, "<!--BARS-->", "<!--/BARS-->", "\n".join(bars))
    html = troca(html, "<!--DESTAQUES-->", "<!--/DESTAQUES-->", dests)
    html = (html.replace("{{PERIODO}}", periodo).replace("{{TITULAR}}", titular)
            .replace("{{ENTRADAS}}", br(entradas)).replace("{{SAIDAS}}", br(saidas))
            .replace("{{SOBROU}}", brs(sobrou))
            .replace("{{SOBROU_COR}}", "#15803d" if sobrou >= 0 else "#b91c1c")
            .replace("{{GERADO_EM}}", datetime.date.today().strftime("%d/%m/%Y")))
    destino.write_text(html, encoding="utf-8")


# ---------------- principal ----------------
def main():
    PAINEL.mkdir(exist_ok=True)
    cfg = carrega_config()
    ident = carrega_identidade()
    arquivos = [p for p in ENTRADA.glob("*") if p.suffix.lower() in (".pdf", ".csv", ".ofx")] if ENTRADA.exists() else []
    if not arquivos:
        print("Nada na pasta entrada/. Baixe o extrato do banco (PDF, CSV ou OFX) e coloque em entrada/.")
        return 1
    extrato = max(arquivos, key=lambda p: p.stat().st_mtime)
    print("Extrato lido:", extrato.name)
    lanc = le_extrato(extrato)
    if not lanc:
        print("Nao consegui ler lancamentos deste arquivo (banco com layout diferente?).")
        print("Exporte em CSV ou OFX, ou peca pra IA ler o PDF no modo normal e salvar um CSV em entrada/.")
        return 1
    regras = carrega_regras()
    for x in lanc:
        x["cat"], x["ac"] = categoriza(x["desc"], x["valor"], regras)

    entradas = sum(x["valor"] for x in lanc if x["valor"] > 0)
    saidas = -sum(x["valor"] for x in lanc if x["valor"] < 0)
    sobrou = entradas - saidas
    por_cat = defaultdict(float)
    for x in lanc:
        if x["valor"] < 0:
            por_cat[x["cat"]] += -x["valor"]
    por_cat = dict(sorted(por_cat.items(), key=lambda kv: -kv[1]))

    datas = sorted(x["data"] for x in lanc)
    periodo = f"{datas[0]} a {datas[-1]}"
    monta_planilha(lanc, PAINEL / f"planilha-financas-{HOJE}.xlsx")
    dest = gera_destaques(lanc, por_cat, saidas, sobrou, cfg["meta"])
    monta_painel(entradas, saidas, sobrou, por_cat, dest, periodo,
                 "Extrato de " + extrato.name, PAINEL / f"painel-financas-{HOJE}.html", ident)

    negocio_linha = None
    if cfg["negocio"]:
        negocio_linha = processa_negocio(cfg["margem"], PAINEL / f"negocio-financas-{HOJE}.md")

    resumo = [f"# Resumo financeiro, {datetime.date.today().strftime('%d/%m/%Y')}", "",
              f"Extrato lido: {extrato.name} ({len(lanc)} lancamentos, periodo {periodo})", "",
              f"- Entrou: R$ {br(entradas)}", f"- Saiu: R$ {br(saidas)}",
              f"- Sobrou: R$ {brs(sobrou)}", "", "## O que chamou atencao"]
    resumo += [f"- {t}" for _, t in dest]
    if negocio_linha:
        resumo += ["", "## Negocio", f"- {negocio_linha}"]
    resumo += ["", "Painel: painel/painel-financas-" + HOJE + ".html",
               "Planilha (contas por formula): painel/planilha-financas-" + HOJE + ".xlsx",
               "", "Nada foi alterado, pago ou movido. Numeros calculados por formula."]
    (PAINEL / f"resumo-financas-{HOJE}.md").write_text("\n".join(resumo), encoding="utf-8")

    print(f"Entrou R$ {br(entradas)} | Saiu R$ {br(saidas)} | Sobrou R$ {brs(sobrou)}")
    if negocio_linha:
        print(negocio_linha)
    print("Gerado em painel/: painel, planilha, resumo", "e negocio" if negocio_linha else "", "de", HOJE)
    return 0


if __name__ == "__main__":
    sys.exit(main())
