# Configuração da rodada automática mensal

Preencha uma vez. A `/financas` lê este arquivo quando roda sozinha (uma vez por mês),
pra não precisar te perguntar nada. Pode deixar como está pra usar os padrões.

- De quem é: Você (finanças pessoais)
- Pasta de entrada (onde os extratos caem): entrada/
- Pasta do painel (onde salvar o resultado): painel/
- Dia do mês pra rodar: 1
- Minha meta de quanto quero que sobre por mês: 4000   (deixe em branco se não tiver)
- Tenho negócio pra incluir a camada de negócio? sim   (troque por "não" se não vender nada)
- Margem de lucro que eu quero no preço: 30%   (usada no cálculo de preço por markup)

Lembre: a tarefa só dispara com o computador ligado e o app aberto naquela hora.
No automático, nada é alterado nem pago: só é gerado o painel, e o que não der pra categorizar
sozinho fica marcado como "A classificar" pra você revisar depois.

Os valores acima (meta 4000, negócio sim) são EXEMPLO pra aula. Troque pelos seus.
