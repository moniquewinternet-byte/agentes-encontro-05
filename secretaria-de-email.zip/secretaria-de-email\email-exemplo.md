# Caixa de entrada de exemplo (teste do /email)

Caixa fictícia, pra testar a lógica do /email sem precisar conectar o Gmail.
16 e-mails, do mais recente pro mais antigo.

1. De: Raisa <raisa@email.com> | Assunto: Quero renovar! Como faço pra entrar? | há 2 dias | "Amei o workshop, quero garantir minha vaga, me manda o link do pagamento?"
2. De: Contato XPTO Eventos <eventos@xpto.com.br> | Assunto: Proposta de palestra, aguardando retorno | há 5 dias | "Seguimos no aguardo do seu retorno sobre a palestra de novembro."
3. De: Ana Paula <anapaula@email.com> | Assunto: Não recebi o acesso do workshop | há 3 dias | "Comprei ontem e ainda não chegou o acesso, consegue verificar?"
4. De: Neil Patel <neil@npdigital.com> | Assunto: 7 SEO hacks you need in 2026 | há 1 dia | newsletter
5. De: Shopee Ofertas <no-reply@shopee.com.br> | Assunto: SUPER OFERTAS só hoje | há 4 horas | promoção
6. De: Michelle <michelle@email.com> | Assunto: Dúvida sobre a aula | há 1 dia | "Travei na parte de instalar, pode me ajudar?"
7. De: Prêmios Online <ganhador@premio-br.com> | Assunto: VOCÊ GANHOU um iPhone | há 6 horas | spam
8. De: Spotify for Creators <creators@spotify.com> | Assunto: Convite: seu podcast no programa de criadores | há 3 dias | "Gostaríamos de te convidar."
9. De: Mari <mari@email.com> | Assunto: Reunião amanhã 15h, confirma? | há 1 dia | "Fecho nossa call amanhã às 15h?"
10. De: Medium Daily <noreply@medium.com> | Assunto: Today's highlights for you | há 1 dia | newsletter
11. De: Carla <carla@email.com> | Assunto: Posso parcelar? | há 4 dias | "Quero muito entrar, consigo em 12x?"
12. De: Editora Livro <revisao@editora.com.br> | Assunto: Revisão do seu capítulo até sexta | há 2 dias | "Precisamos da sua revisão do capítulo 4 até sexta."
13. De: Kiwify Promo <promo@kiwify.com.br> | Assunto: Black Friday antecipada | há 5 horas | promoção
14. De: Grupo Família <mae@email.com> | Assunto: Jantar domingo | há 1 dia | pessoal
15. De: LinkedIn <no-reply@linkedin.com> | Assunto: Você apareceu em 9 buscas | há 2 dias | notificação
16. De: Banco <no-reply@banco.com.br> | Assunto: Sua fatura fechou | há 1 dia | aviso automático
