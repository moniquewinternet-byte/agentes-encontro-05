# O que a assistente aprendeu sobre esta caixa de entrada

Atualizado a cada uso. Guarda só REGRAS, nunca o conteúdo dos e-mails.

## Pessoas que importam (prioridade alta)
- Alunas e clientes: sempre no topo.
- Parceiros de trabalho: resposta rápida.

## Assuntos que são sempre prioridade
- Alguém esperando resposta ou decisão sua.
- Cliente, venda, proposta, pedido.
- Acesso ou suporte de quem comprou (experiência de quem pagou).

## O que é sempre ruído (pode agrupar pra faxina)
- Newsletter e digests.
- Promoção e oferta.
- Spam e remetentes de "prêmio/ganhador".
